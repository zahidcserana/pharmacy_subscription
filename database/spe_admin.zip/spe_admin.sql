-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 27, 2020 at 06:04 AM
-- Server version: 8.0.21-0ubuntu0.20.04.4
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spe_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `change_requests`
--

CREATE TABLE `change_requests` (
  `id` bigint UNSIGNED NOT NULL,
  `pharmacy_id` bigint UNSIGNED NOT NULL,
  `feature` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_type` enum('FREE','FULLY-PAID','PARTIAL-PAID') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FREE',
  `status` enum('Pending','Ongoing','Done') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `collected_by` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint UNSIGNED NOT NULL,
  `pharmacy_id` int DEFAULT NULL,
  `pharmacy_branch_id` int DEFAULT NULL,
  `coupon_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL DEFAULT '0',
  `apply_date` datetime DEFAULT NULL,
  `coupon_type` enum('1MONTH','3MONTH','6MONTH','1YEAR') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1MONTH',
  `status` enum('ACTIVE','INACTIVE','USED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `generated_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activated_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `pharmacy_id`, `pharmacy_branch_id`, `coupon_code`, `amount`, `apply_date`, `coupon_type`, `status`, `generated_by`, `activated_by`, `created_at`, `updated_at`) VALUES
(1, 2, 15, '99WHTN3V825AXIP0', 500, '2020-09-10 05:54:27', '1MONTH', 'USED', '4', NULL, '2019-12-22 05:33:12', '2020-09-09 23:54:27'),
(2, NULL, NULL, 'S9NT8F9IIG13DBRR', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2019-12-22 05:33:12', '2019-12-22 05:33:12'),
(3, 1, 14, 'QNJF3MS631OV5HTX', 500, '2020-01-20 08:42:07', '1MONTH', 'USED', '4', 'Sazzad Hossain', '2019-12-22 05:33:12', '2020-01-20 02:42:07'),
(4, NULL, NULL, '5HX35CSY6VLYZ06V', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-01-21 01:20:37', '2020-01-21 01:20:37'),
(5, NULL, NULL, '79HMPV06I0HEEAKL', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:30', '2020-10-12 04:26:30'),
(6, NULL, NULL, 'BX6M1MVBCUMKCR9V', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:26:31'),
(7, NULL, NULL, 'FA7JKT8WEEU8FD4D', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:26:31'),
(8, NULL, NULL, '6127W0ZGTY6VRT8U', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:26:31'),
(9, NULL, NULL, '5QLKAFDPC0HZK6CI', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:26:31'),
(10, NULL, NULL, 'Q7QG6C4DN8C9UQ3F', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:26:31'),
(11, NULL, NULL, 'EAPIHGUDLDGAP6HQ', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:26:31'),
(12, NULL, NULL, 'T46WDIY55AOIZSFH', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:26:31'),
(13, NULL, NULL, 'NG2X90DIV9FH7HHS', 500, NULL, '1MONTH', 'ACTIVE', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:26:31'),
(14, 2, 15, 'H4IKNUFT2CJ04PQT', 500, '2020-10-12 10:30:41', '1MONTH', 'USED', '4', NULL, '2020-10-12 04:26:31', '2020-10-12 04:30:41');

-- --------------------------------------------------------

--
-- Table structure for table `installation_bills`
--

CREATE TABLE `installation_bills` (
  `id` bigint UNSIGNED NOT NULL,
  `pharmacy_id` bigint UNSIGNED NOT NULL,
  `pay_date` datetime NOT NULL,
  `payment_for` enum('Installation Bill','Others') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Installation Bill',
  `payment_type` enum('Partial','Full') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Full',
  `month` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_by` enum('Cash','Cheque','bKash','Bank') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cash',
  `collected_by` bigint UNSIGNED DEFAULT NULL,
  `amount` double(8,2) NOT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_11_03_103927_create_smart_pharmacies_table', 2),
(4, '2019_11_03_111143_add_start_date_to_smart_pharmacies_table', 3),
(5, '2019_11_04_074926_create_change_requests_table', 4),
(12, '2019_11_05_075717_create_coupons_table', 5),
(13, '2019_11_05_125210_create_monthly_bills_table', 5),
(14, '2019_11_12_081348_add_pharmacy_code_to_smart_pharmacies_table', 6),
(15, '2019_11_12_082552_add_validity-period_to_smart_pharmacies_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `monthly_bills`
--

CREATE TABLE `monthly_bills` (
  `id` bigint UNSIGNED NOT NULL,
  `pharmacy_id` bigint UNSIGNED NOT NULL,
  `pay_date` datetime NOT NULL,
  `payment_for` enum('Feature Development','Report','Monthly Bill','Others') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Monthly Bill',
  `payment_type` enum('Partial','Full') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Full',
  `month` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_by` enum('Cash','Cheque','bKash','Bank') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cash',
  `collected_by` bigint UNSIGNED DEFAULT NULL,
  `amount` double(8,2) NOT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `monthly_bills`
--

INSERT INTO `monthly_bills` (`id`, `pharmacy_id`, `pay_date`, `payment_for`, `payment_type`, `month`, `payment_by`, `collected_by`, `amount`, `remarks`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-12-18 00:00:00', 'Monthly Bill', 'Full', '2019-11', 'Cash', 5, 500.00, 'Monthly Bill', '2019-12-19 05:39:09', '2019-12-19 05:39:09'),
(2, 1, '2020-03-03 00:00:00', 'Monthly Bill', 'Full', '2020-02', 'Cash', 1, 500.00, '#INV03032020 (Mr. Tussher)', '2020-03-04 00:47:38', '2020-03-04 00:47:38'),
(3, 2, '2020-09-10 00:00:00', 'Monthly Bill', 'Full', '2020-08', 'bKash', 4, 500.00, 'Maa pharmacy paid for August.', '2020-09-10 00:08:37', '2020-09-10 00:08:37'),
(4, 2, '2020-10-12 00:00:00', 'Monthly Bill', 'Full', '2020-09', 'Cash', 4, 500.00, 'Monthly Bill', '2020-10-13 02:49:37', '2020-10-13 02:49:37');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smart_pharmacies`
--

CREATE TABLE `smart_pharmacies` (
  `id` bigint UNSIGNED NOT NULL,
  `pharmacy_code` int NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_pharmacy_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive','removed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `validity` int NOT NULL DEFAULT '0',
  `use_count` int NOT NULL DEFAULT '0',
  `start_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `smart_pharmacies`
--

INSERT INTO `smart_pharmacies` (`id`, `pharmacy_code`, `name`, `address`, `location`, `owner_name`, `license_no`, `model_pharmacy_no`, `contact_person`, `mobile_no`, `status`, `validity`, `use_count`, `start_date`, `created_at`, `updated_at`) VALUES
(1, 14, 'Shohag Pharma', 'Zigatola, Dhaka', 'Zigatola', 'Rinku Debnath Joy Debnath', '1010568630', '18067', 'Rinku Debnath', '01711709924', 'active', 0, 0, '2019-10-20', '2019-12-15 06:10:12', '2019-12-15 06:10:12'),
(2, 15, 'MAA Pharmacy & Medicine Super Shop', 'House#42, Gareeb-e-newaz avenue, Sector-13, Uttara', 'Uttara', 'Md. Jewel', '18011074849', 'DG-8990', 'Md. Jewel', '01711709924', 'active', 150, 127, '2019-11-26', '2019-12-15 06:17:28', '2020-10-12 04:30:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` enum('ADMIN','EXECUTIVE','STAFF') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EXECUTIVE',
  `status` enum('active','inactive','removed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `designation`, `address`, `email_verified_at`, `password`, `user_type`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hosne Mobarak Rubai', 'rubai.mobarak@gmail.com', '01714536772', 'Sr. Software Engineer', 'Niketon, Dhaka', NULL, '$2y$10$ivQzzIi.01jxCgGkzFzx6OFvyVv1XsY4vgV3sYissZZPW1Fx6sTFC', 'ADMIN', 'active', NULL, '2019-11-01 11:32:17', '2019-11-01 11:32:17'),
(4, 'Administrator', 'admin@admin.com', '01992599664', 'Software Engineer', 'Niketon, Dhaka', NULL, '$2y$10$o7MMM4S7krQxAZEo4WgBEuOE66sj2.12DGz0nsK2ipMLi2fZXGHZi', 'ADMIN', 'active', NULL, '2019-11-01 11:38:11', '2019-11-01 11:38:11'),
(5, 'Sazzad', 'sazzad@gmail.com', '01680628610', 'Marketing Executive', 'Dhaka', NULL, '$2y$10$yI.l88eE8S2KVerDV1fTouBblWbsbbEaO/xLRy0Uzri8TEsrnQTu6', 'STAFF', 'active', NULL, '2019-11-03 03:20:40', '2019-11-03 03:20:40'),
(6, 'Mahbub Majumder', 'mahbub.majumder@afc.com.bd', '01766682135', 'Managing Director', 'Niketon, Dhaka', NULL, '$2y$10$ivQzzIi.01jxCgGkzFzx6OFvyVv1XsY4vgV3sYissZZPW1Fx6sTFC', 'ADMIN', 'active', NULL, '2019-11-01 11:32:17', '2019-11-01 11:32:17'),
(7, 'Tasbi', 'tasbi.kc@gmail.com', '01738008181', 'HR & Admin Officer', 'House#87-89, Road#4, Block#B\r\nCerebrum Technology Ltd.', NULL, '$2y$10$MzazEdeW5WAgQTRfpNe1MOFmO9wGRi05MDxVin2Hf6COdHVdm7may', 'EXECUTIVE', 'active', NULL, '2019-12-19 05:42:29', '2019-12-19 05:42:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `change_requests`
--
ALTER TABLE `change_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `change_requests_collected_by_foreign` (`collected_by`),
  ADD KEY `change_requests_pharmacy_id_foreign` (`pharmacy_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `installation_bills`
--
ALTER TABLE `installation_bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `installation_bills_collected_by_foreign` (`collected_by`),
  ADD KEY `installation_bills_pharmacy_id_foreign` (`pharmacy_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monthly_bills`
--
ALTER TABLE `monthly_bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `monthly_bills_collected_by_foreign` (`collected_by`),
  ADD KEY `monthly_bills_pharmacy_id_foreign` (`pharmacy_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(191));

--
-- Indexes for table `smart_pharmacies`
--
ALTER TABLE `smart_pharmacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `change_requests`
--
ALTER TABLE `change_requests`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `installation_bills`
--
ALTER TABLE `installation_bills`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `monthly_bills`
--
ALTER TABLE `monthly_bills`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `smart_pharmacies`
--
ALTER TABLE `smart_pharmacies`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `change_requests`
--
ALTER TABLE `change_requests`
  ADD CONSTRAINT `change_requests_collected_by_foreign` FOREIGN KEY (`collected_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `change_requests_pharmacy_id_foreign` FOREIGN KEY (`pharmacy_id`) REFERENCES `smart_pharmacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `installation_bills`
--
ALTER TABLE `installation_bills`
  ADD CONSTRAINT `installation_bills_collected_by_foreign` FOREIGN KEY (`collected_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `installation_bills_pharmacy_id_foreign` FOREIGN KEY (`pharmacy_id`) REFERENCES `smart_pharmacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `monthly_bills`
--
ALTER TABLE `monthly_bills`
  ADD CONSTRAINT `monthly_bills_collected_by_foreign` FOREIGN KEY (`collected_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `monthly_bills_pharmacy_id_foreign` FOREIGN KEY (`pharmacy_id`) REFERENCES `smart_pharmacies` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
